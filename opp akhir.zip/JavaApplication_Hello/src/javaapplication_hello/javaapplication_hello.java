/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication_hello;

/**
 *
 * @author evanp
 */
public class javaapplication_hello {
    public static void main(String[] args){
    }
}
